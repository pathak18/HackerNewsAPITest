﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Web.Script.Serialization;

namespace BestHackerNewsAPI
{
    public partial class BestHackerNews : System.Web.UI.Page
    {
        Dictionary<string, string> bestStories = new Dictionary<string, string>();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetBestStory();
            }

            gvHackerNews.DataSource = bestStories;
            gvHackerNews.DataBind();
        }

        /// <summary>
        /// Gets the best sotries.
        /// </summary>
        public void GetBestStory()
        {
            List<string> ids = new List<string>();
            ids = GetBestList();

            IterateList(ids);
        }

        /// <summary>
        /// Returns the IDs of 25 best stories only (getting all might be slower) in a list.
        /// </summary>
        /// <param name="limit"></param>
        /// <returns></returns>
        public List<string> GetBestList(int limit = 25) 
        {            
            HttpWebRequest r = (HttpWebRequest)WebRequest.Create(Constants.BESTSTORIES);
            r.Method = WebRequestMethods.Http.Get;
            r.Accept = "application/json";
            WebResponse resp = r.GetResponse();
            DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(List<string>));
            List<string> lst = (List<string>)serializer.ReadObject(resp.GetResponseStream());

            return lst.GetRange(0, Math.Min(limit, 25));            
        }
               
        /// <summary>
        /// Loops through each story id to extract more info.
        /// </summary>
        /// <param name="ids"></param>
        /// <param name="limit"></param>
        public void IterateList(List<string> ids)
        {   
            foreach (string i in ids)
            {                
                AddStoryInfo(i);
            }                        
        }
        
        /// <summary>
        /// Adds title and auther of each story in a disctionary object
        /// </summary>
        /// <param name="id"></param>
                        
        public void AddStoryInfo(string id)
        {
            try
            { 
                Dictionary<string, dynamic> dict = GetStoryItem(id);
                if (dict.Count > 0)
                {
                    string title = dict["title"];
                    string author = dict["by"];

                    bestStories.Add(title, author);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error occurd at AddStoryInfo() " + ex.Message);
            }
        }

        /// <summary>
        /// returns each story based on story id.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Dictionary<string, dynamic> GetStoryItem(string id)
        {
            string jsonString = string.Empty;
            JavaScriptSerializer js = new JavaScriptSerializer();
            try
            {
                HttpWebRequest reqst = (HttpWebRequest)WebRequest.Create(String.Format(Constants.ITEM, id));
                reqst.Method = WebRequestMethods.Http.Get;
                reqst.Accept = "application/json";

                WebResponse resp = reqst.GetResponse();
                using (var sr = new StreamReader(resp.GetResponseStream()))
                {
                    jsonString = sr.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error occurd at GetStoryItem() " + ex.Message);
            }
            return js.Deserialize<Dictionary<string, dynamic>>(jsonString);
        }

    }
}