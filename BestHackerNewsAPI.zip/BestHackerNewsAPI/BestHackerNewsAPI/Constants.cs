﻿namespace BestHackerNewsAPI
{
    public static class Constants
    {
        public const string BASEURL = "https://hacker-news.firebaseio.com/v0/";        
        public const string TOPSTORIES = BASEURL + "topstories.json";
        public const string BESTSTORIES = BASEURL + "beststories.json";
        public const string ITEM = BASEURL + "item/{0}.json";
    }
}